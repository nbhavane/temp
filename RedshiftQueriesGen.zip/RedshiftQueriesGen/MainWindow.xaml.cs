﻿using Microsoft.Win32;
using System;
using System.Collections.Generic;
using System.IO;
using System.Text;
using System.Windows;

namespace SQLGrantQueryGenerator
{
    public partial class MainWindow : Window
    {
        private List<string> usernames;
        private List<string> schemas;

        public MainWindow()
        {
            InitializeComponent();
            usernames = new List<string>();
            schemas = new List<string>();
        }

        private void AddUsersButton_Click(object sender, RoutedEventArgs e)
        {
            int numUsers;
            if (int.TryParse(NumUsersTextBox.Text, out numUsers))
            {
                for (int i = 0; i < numUsers; i++)
                {
                    string username = Microsoft.VisualBasic.Interaction.InputBox($"Enter username {i + 1}:");
                    if (!string.IsNullOrEmpty(username))
                    {
                        usernames.Add(username);
                        UserListBox.Items.Add(username);
                    }
                }
            }
            else
            {
                MessageBox.Show("Please enter a valid number of users.", "Input Error", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        private void AddSchemasButton_Click(object sender, RoutedEventArgs e)
        {
            int numSchemas;
            if (int.TryParse(NumSchemasTextBox.Text, out numSchemas))
            {
                for (int i = 0; i < numSchemas; i++)
                {
                    string schema = Microsoft.VisualBasic.Interaction.InputBox($"Enter schema {i + 1}:");
                    if (!string.IsNullOrEmpty(schema))
                    {
                        schemas.Add(schema);
                        SchemaListBox.Items.Add(schema);
                    }
                }
            }
            else
            {
                MessageBox.Show("Please enter a valid number of schemas.", "Input Error", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        private void GenerateButton_Click(object sender, RoutedEventArgs e)
        {
            if (usernames.Count == 0 || schemas.Count == 0)
            {
                MessageBox.Show("Please enter at least one user and one schema.", "Generation Error", MessageBoxButton.OK, MessageBoxImage.Error);
                return;
            }

            string accessType = AccessTypeComboBox.Text;
            bool isReadOnly = (accessType == "Read Only");
            bool isReadWrite = (accessType == "Read Write");
            bool isAllRo = (accessType == "All RO");
            bool isAllRw = (accessType == "All RW");

            StringBuilder output = new StringBuilder();

            foreach (string username in usernames)
            {
                foreach (string schema in schemas)
                {
                    // Generate the grant query for each combination of user and schema
                    string accessTypeString = isReadOnly ? "ro" : "rw";

                    if (isReadOnly)
                    {
                        // Generate the query for Read Only access type
                        string query = $"ALTER GROUP local_redshift_{BusinessUnitTextBox.Text}_users_{schema}_{accessTypeString}\n" +
                                       $"ADD USER \"{username}@jazzpharma.com\";\n";
                        string queryy = $"----------------------------------------------------------------------------------------------------";

                        // Append the query to the output
                        output.AppendLine(query);
                        output.AppendLine(queryy);
                    }
                    if (isReadWrite)
                    {
                        // Generate the query for Read Write access type
                        string query2 = $"ALTER GROUP local_redshift_{BusinessUnitTextBox.Text}_users_{schema}_{accessTypeString}\n" +
                                       $"ADD USER \"{username}@jazzpharma.com\";\n";
                        string query3 = $"ALTER DEFAULT PRIVILEGES IN SCHEMA {schema} for user \"{username}@jazzpharma.com\"\n" + 
                                        $"GRANT ALL ON TABLES TO GROUP local_redshift_{BusinessUnitTextBox.Text}_users_{schema}_{accessTypeString};\n";
                        string query4 = $"ALTER DEFAULT PRIVILEGES IN SCHEMA {schema} for user \"{username}@jazzpharma.com\"\n" +
                                        $"GRANT SELECT ON TABLES TO GROUP local_redshift_{BusinessUnitTextBox.Text}_users_{schema}_ro;\n";
                        string query5 = $"alter default privileges for user \"{username}@jazzpharma.com\" in schema {schema}\n" +
                                        $"grant all on tables to group local_redshift_{BusinessUnitTextBox.Text}_all_{accessTypeString};\n";
                        string query6 = $"alter default privileges for user \"{username}@jazzpharma.com\" in schema {schema}\n" +
                                        $"grant select on tables to group local_redshift_{BusinessUnitTextBox.Text}_all_ro;\n";
                        string query7 = $"Grant all on schema {schema} to group local_redshift_{BusinessUnitTextBox.Text}_users_{schema}_{accessTypeString};\n" +
                                        $"grant all on all tables in schema {schema} to group local_redshift_{BusinessUnitTextBox.Text}_users_{schema}_{accessTypeString};\n";
                        string query8 = $"Grant usage on schema {schema} to group local_redshift_{BusinessUnitTextBox.Text}_users_{schema}_ro;\n" +
                                        $"grant select on all tables in schema {schema} to group local_redshift_{BusinessUnitTextBox.Text}_users_{schema}_ro;\n";
                        string query9 = $"Grant all on schema {schema} to group local_redshift_{BusinessUnitTextBox.Text}_all_{accessTypeString};\n" +
                                        $"grant all on all tables in schema {schema} to group local_redshift_{BusinessUnitTextBox.Text}_all_{accessTypeString};\n";
                        string query10 = $"Grant usage on schema {schema} to group local_redshift_{BusinessUnitTextBox.Text}_all_ro;\n" +
                                         $"grant select on all tables in schema {schema} to group local_redshift_{BusinessUnitTextBox.Text}_all_ro;\n";
                        string query11 = $"----------------------------------------------------------------------------------------------------\n";
                                        



                        // Append the queries to the output
                        output.AppendLine(query2);
                        output.AppendLine(query3);
                        output.AppendLine(query4);
                        output.AppendLine(query5);
                        output.AppendLine(query6);
                        output.AppendLine(query7);
                        output.AppendLine(query8);
                        output.AppendLine(query9);
                        output.AppendLine(query10);
                        output.AppendLine(query11);

                    }
                    if (isAllRo)
                    {
                        string query12 = $"ALTER GROUP local_redshift_{BusinessUnitTextBox.Text}_all_ro\n" +
                                         $"ADD USER \"{username}@jazzpharma.com\";\n";
                        string query13 = $"alter default privileges for user \"{username}@jazzpharma.com\" grant select on tables to group local_redshift_{BusinessUnitTextBox.Text}_all_ro\n";
                        string query14 = $"----------------------------------------------------------------------------------------------------\n";
                        // Append the queries to the output
                        output.AppendLine(query12);
                        output.AppendLine(query13);
                        output.AppendLine(query14);

                    }
                    if (isAllRw)
                    {
                        string query15 = $"ALTER GROUP local_redshift_{BusinessUnitTextBox.Text}_all_rw\n" +
                                         $"ADD USER \"{username}@jazzpharma.com\";\n";
                        string query16 = $"alter default privileges for user \"{username}@jazzpharma.com\" grant all on tables to group local_redshift_{BusinessUnitTextBox.Text}_all_rw\n";
                        string query17 = $"alter default privileges for user \"{username}@jazzpharma.com\" grant select on tables to group local_redshift_{BusinessUnitTextBox.Text}_all_ro\n";
                        string query18 = $"----------------------------------------------------------------------------------------------------\n";

                        // Append the queries to the output
                        output.AppendLine(query15);
                        output.AppendLine(query16);
                        output.AppendLine(query17);
                        output.AppendLine(query18);

                    }

                }
            }

            // Display the generated queries
            OutputTextBox.Text = output.ToString();
        }

        private void SaveButton_Click(object sender, RoutedEventArgs e)
        {
            string query = OutputTextBox.Text;

            if (string.IsNullOrEmpty(query))
            {
                MessageBox.Show("There are no SQL Grant queries to save.", "Save Error", MessageBoxButton.OK, MessageBoxImage.Error);
                return;
            }

            SaveFileDialog saveFileDialog = new SaveFileDialog();
            saveFileDialog.Filter = "Text Files|*.txt";
            saveFileDialog.Title = "Save SQL Grant Queries";

            if (saveFileDialog.ShowDialog() == true)
            {
                // Save the generated queries to a text file
                File.WriteAllText(saveFileDialog.FileName, query);
                MessageBox.Show("SQL Grant queries saved successfully!", "Save Complete", MessageBoxButton.OK, MessageBoxImage.Information);
            }
        }
    }
}
